Commands:
- Build Docker image: docker build -t version-control-website .
- Run Docker container: docker run -p 5000:5000 version-control-website
- Access at http://localhost:5000

GitHub repo: https://github.com/u24569624/220-project.git